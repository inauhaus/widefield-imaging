function LoadImageInfo(trial)

setacqinfo(trial);