

bwCell1 = MakeCellMask(14,.8,3);

bwR{1} = roipoly;  %LM ROI
bwR{2} = roipoly;  %V1 ROI


ROICompare(bwR,bwCell1);





