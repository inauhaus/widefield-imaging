function setAnalyzerDirectory(path)

global anadir

anadir = path;
