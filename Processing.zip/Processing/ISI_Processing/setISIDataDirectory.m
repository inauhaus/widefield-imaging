function setISIDataDirectory(path)

global datadir

datadir = path;
