
function G = intersectfitguess

%Double check Initial guesses

global D S

G = mean(S);
