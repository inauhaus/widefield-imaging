
function G = spherefitguess

G = [0 0 -12 12.5];
