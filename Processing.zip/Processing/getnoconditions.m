function nc = getnoconditions


global Analyzer

nc = length(Analyzer.loops.conds);